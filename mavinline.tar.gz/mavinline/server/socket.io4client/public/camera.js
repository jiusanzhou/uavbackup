(function(){    
    // Setup the WebSocket connection and start the player
    
    
})()