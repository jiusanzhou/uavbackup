ps -ef|grep main.py|cut -c 9-15|xargs sudo kill -9
